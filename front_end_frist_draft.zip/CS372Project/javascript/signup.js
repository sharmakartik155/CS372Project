document.getElementById("SignUp").addEventListener("submit", SignUpForm, true);
document.getElementById("SignUp").addEventListener("reset", ResetForm, false);
