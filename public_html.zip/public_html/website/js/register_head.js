document.getElementById("create_post_head").addEventListener("input", validate_head, false);
document.getElementById("create_post_send").addEventListener("click", validate_head, false);
