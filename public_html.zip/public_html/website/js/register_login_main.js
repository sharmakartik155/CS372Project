document.getElementById("login_main_form").addEventListener("submit", validate_login_main, false);
