document.getElementById("create_post_body").addEventListener("input", validate_body, false);
document.getElementById("create_post_send").addEventListener("click", validate_body, false);
