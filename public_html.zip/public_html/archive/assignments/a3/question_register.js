document.getElementById("question_create").addEventListener("input", question_validate, false);
document.getElementById("question_create").addEventListener("submit", question_validate, false);
