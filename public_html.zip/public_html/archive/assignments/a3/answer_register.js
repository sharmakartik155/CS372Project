document.getElementById("answer_create").addEventListener("input", answer_validate, false);
document.getElementById("answer_create").addEventListener("submit", answer_validate, false);
