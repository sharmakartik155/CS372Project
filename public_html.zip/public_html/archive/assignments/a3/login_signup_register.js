document.getElementById("login_signup").addEventListener("submit", login_signup_validate, false);
