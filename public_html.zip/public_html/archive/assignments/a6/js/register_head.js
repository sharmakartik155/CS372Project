document.getElementById("create_post").addEventListener("input", validate_head, false);
document.getElementById("create_post").addEventListener("submit", validate_head, false);
