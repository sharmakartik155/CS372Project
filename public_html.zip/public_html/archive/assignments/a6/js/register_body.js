document.getElementById("create_post").addEventListener("input", validate_body, false);
document.getElementById("create_post").addEventListener("submit", validate_body, false);
