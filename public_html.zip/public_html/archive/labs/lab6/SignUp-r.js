document.getElementById("SignUp").addEventListener("submit", SignUpForm, false);
document.getElementById("SignUp").addEventListener("reset", ResetForm, false);
