<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" src="../js/login_header_validate.js"></script>  
<link rel="stylesheet" type="text/css" href="../css/sm_scr.css" />
<link rel="stylesheet" type="text/css" href="../css/lg_scr.css" media= "screen and (min-width: 305px)">
