	<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<link rel="stylesheet" type="text/css" href="../css/tablet.css" />
			<link rel="stylesheet" type="text/css" href="../css/desktop.css" media= "screen and (min-width: 888px)">
			<link rel="stylesheet" type="text/css" href="../css/phone.css" media= "screen and (max-width: 666px)">
			<link rel="stylesheet" type="text/css" href="../css/tiny.css" media= "screen and (max-width: 333px)">
			<script type="text/javascript" src="../js/login_header_validate.js"></script>
